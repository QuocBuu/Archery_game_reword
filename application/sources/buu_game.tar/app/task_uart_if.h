#ifndef __TASK_UART_IF_H__
#define __TASK_UART_IF_H__

#include <stdint.h>

#endif //__TASK_UART_IF_H__
