#ifndef __TASK_IF_H__
#define __TASK_IF_H__

#include <stdint.h>
#include <stdbool.h>

#include "ak.h"
#include "message.h"

#endif // __TASK_IF_H__
