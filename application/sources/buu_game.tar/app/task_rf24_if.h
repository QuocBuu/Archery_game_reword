#ifndef __TASK_RF24_IF_H__
#define __TASK_RF24_IF_H__

#include <stdint.h>

#endif // __TASK_RF24_IF_H__
