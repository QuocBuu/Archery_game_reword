#ifndef __TASK_LIFE__
#define __TASK_LIFE__

#include "led.h"

extern led_t led_life;

#endif //__TASK_LIFE__
