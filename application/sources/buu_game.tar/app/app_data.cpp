#include "app_data.h"

/* global modbus object */
#if defined (TASK_MBMASTER_EN)
xMBHandle xMBMMaster;
#endif
